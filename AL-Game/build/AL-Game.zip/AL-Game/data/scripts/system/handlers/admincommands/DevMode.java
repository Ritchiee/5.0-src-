package admincommands;

import com.aionemu.gameserver.model.gameobjects.player.Player;
import com.aionemu.gameserver.utils.chathandlers.AdminCommand;

/**
 * Created by Kill3r
 */
public class DevMode extends AdminCommand {

    public DevMode() {
        super("dev");
    }

    public void execute(Player admin, String...params){

    }
}
